export const authData = {
    user1:{
        "name": "Admin",
        "permission": "all",
        "password":"Admin"
    },
    user2:{
        "name": "myName",
        "permission": "none",
        "password":"test"
    }
}